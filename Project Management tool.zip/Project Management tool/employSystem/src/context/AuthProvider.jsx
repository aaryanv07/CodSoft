import React, { createContext, useEffect, useState } from "react";
import { getLocalStorage, setLocalStorage } from "../utils/LocalStorage";

export const AuthContext = createContext();

const AuthProvider = ({ children }) => {
  
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    // Assuming getLocalStorage returns an object with { employees, admin }
    const { employees,admin} = getLocalStorage();
    setUserData( employees);
  }, []); // Empty dependency array to run this effect only once

  console.log(userData);

  return (
    <AuthContext.Provider value={[userData, setUserData]}>
      {children}
    </AuthContext.Provider>
  );


  
};

export default AuthProvider;
