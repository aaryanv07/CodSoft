import React from "react";

const FailedTask = ({data}) => {
  return (
    <div>
      <div className="h-full flex-shrink-0 w-[300px] bg-yellow-400 rounded-xl text-white">
        <div className="flex items-center justify-between p-5">
          <h3 className="bg-red-600 text-sm px-3 py-1 rounded">{data.category}</h3>
          <h4 className="text-sm">{data.date}</h4>
        </div>
        <h2 className="mt-5 text-2xl font-semibold text-2xl px-5">
          {data.title}
        </h2>

        <p className="text-sm mt-2 px-5">
          {data.description}
        </p>
        <div className="mt-2">
          <button className="w-full">Failed</button>
        </div>
      </div>
    </div>
  );
};

export default FailedTask;
