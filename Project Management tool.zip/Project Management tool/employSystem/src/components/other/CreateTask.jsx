import React, { useState, useContext } from "react";
import { AuthContext } from "../../context/AuthProvider";

const CreatenewTask = () => {
  const [newTaskTitle, setnewTaskTitle] = useState("");
  const [date, setDate] = useState("");
  const [assignTo, setAssignTo] = useState("");
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [newTask, setnewTask] = useState([]);
  const [userData,setUserData] = useContext(AuthContext);

  const submitHandler = (e) => {
    e.preventDefault();

    const newTasks = {
      newTaskTitle,
      date,
      assignTo,
      category,
      description,
      active: false,
      newTask: true,
      failed: false,
      completed: false,
    };
    setnewTask((prevnewTask) => [...prevnewTask, newTasks]);
    

    // const data = JSON.parse(localStorage.getItem("employees"));
    // const data = JSON.parse(localStorage.getItem("employees"));

    data.forEach((element) => {
      if (assignTo == element.firstName) {
        element.tasks.push(newTask);
        element.taskCounts.newTask = element.taskCounts.newTask + 1;
      }
    });

    setUserData(data)
    // localStorage.setItem("employees", JSON.stringify(data));
    setnewTaskTitle("");
    setDate("");
    setAssignTo("");
    setCategory("");
    setDescription("");
    setnewTask("");
    
  };

  return (
    <div className="p-5 bg-[#1c1c1c] mt-7 rounded">
      <form
        onSubmit={submitHandler}
        className="flex flex-wrap w-full bg-gray-700 items-start p-5 justify-between"
      >
        <div className="w-1/2">
          <div className="mb-3">
            <h3 className="text-sm text-gray-300 mb-0.5">newTask Title</h3>
            <input
              value={newTaskTitle}
              onChange={(e) => setnewTaskTitle(e.target.value)}
              className="text-sm py-1 px-2 w-4/5 rounded outline-none bg-transparent border-[1px] border-gray-400"
              type="text"
              placeholder="Make a UI design"
            />
          </div>
          <div className="mb-3">
            <h3 className="text-sm text-gray-300 mb-0.5">Date</h3>
            <input
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="text-sm py-1 px-2 w-4/5 rounded outline-none bg-transparent border-[1px] border-gray-400"
              type="date"
            />
          </div>
          <div className="mb-3">
            <h3 className="text-sm text-gray-300 mb-0.5">Assign to</h3>
            <input
              value={assignTo}
              onChange={(e) => setAssignTo(e.target.value)}
              className="text-sm py-1 px-2 w-4/5 rounded outline-none bg-transparent border-[1px] border-gray-400"
              type="text"
              placeholder="Employee name"
            />
          </div>
          <div className="mb-3">
            <h3 className="text-sm text-gray-300 mb-0.5">Category</h3>
            <input
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="text-sm py-1 px-2 w-4/5 rounded outline-none bg-transparent border-[1px] border-gray-400"
              type="text"
              placeholder="Design, dev, etc."
            />
          </div>
        </div>

        <div className="w-2/5 flex flex-col items-start">
          <h3 className="text-sm text-gray-300 mb-0.5">Description</h3>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full bg-transparent border-[1px] border-gray-400"
            rows={10}
          ></textarea>
          <button className="bg-emerald-500 py-3 hover:bg-emerald-600 px-5 rounded text-sm mt-4 w-full">
            Create newTask
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreatenewTask;
