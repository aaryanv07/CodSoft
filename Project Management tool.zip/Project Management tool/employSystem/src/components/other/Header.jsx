import React, { useEffect, useState } from "react";
import { setLocalStorage } from "../../utils/LocalStorage";

const Header = (props) => {
  const [username, setUsername] = useState("");
  

  const logOutUser = () => {
    localStorage.setItem("loggedInUser", " ");
    
    props.changeUser('');

  };

  return (
    <div className="flex  items-end justify-between">
      <h1 className="text-2xl font-medium text-white ">
        Hello <br></br>
        <span className="text-3xl font-semibold">{username}</span>
      </h1>
      <button
        onClick={logOutUser}
        className="bg-red-600 text-lg font-medium px-3 py-2 rounded-sm"
      >
        Logout
      </button>
    </div>
  );
};

export default Header;
