import React, { useState } from "react";

const Login = ({ handleLogin }) => {
  
  var [email, setEmail] = useState("");
  var [password, setPassword] = useState("");
  const submitHandler = (e) => {
    e.preventDefault();
    console.log(`Form Submitted & email is ${email} & password is ${password}`);
    handleLogin(email,password);
    setEmail("");
    setPassword("");
  };
  return (
    <div className="flex items-center justify-center h-screen w-full bg-black">
      <div className="border-2 border-red-600 p-20 rounded-xl">
        <form
          onSubmit={submitHandler}
          className="flex flex-col items-center justify-center"
        >
          <input
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
            }}
            required
            className="border-2 border-emerald-600 py-3 text-xl text--600 outline-none placeholder:text-black-400 bg-transparent px-5 rounded-full text-white"
            type="email"
            placeholder="Enter your email"
          />
          <input
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
            }}
            required
            className="border-2 border-emerald-600 py-3 text-xl text--600 outline-none placeholder:text-black-400 mt-3 bg-transparent px-5 rounded-full text-white"
            type="password"
            placeholder="Enter Password"
          />
          <button type="submit" className=" mt-5 bg-emerald-600 py-3 text-xl text-black outline-none placeholder:text-red-600 mt-3  px-5 rounded-full">
            Log in
          </button>
        </form>
      </div>
    </div>
  );
};

export default Login;
